from datetime import datetime
import io
import json
import os
import re

from dotenv import load_dotenv
from openai import OpenAI
from pdf2image import convert_from_bytes
import pdfplumber
from PyPDF2 import PdfReader
import pytesseract
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.utils import ImageReader
from reportlab.platypus import HRFlowable, Image as RLImage, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
import streamlit as st
import streamlit.components.v1 as components

# ---------------- ENV & ENGINE SETUP ----------------
load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), ".env"))
pytesseract.pytesseract.tesseract_cmd = (
    r"C:\Program Files\Tesseract-OCR\tesseract.exe"
)

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
MODEL_NAME = "gpt-6-luna"

BASE_DIR = os.path.dirname(__file__)
TEMPLATES_15_DIR = os.path.join(BASE_DIR, "templates_15")
TRAINED_15_JSON = os.path.join(BASE_DIR, "templates_15_trained.json")
FEEDBACK_DB_PATH = os.path.join(BASE_DIR, "feedback_db.json")

POPPLER_CANDIDATES = [
    r"C:\Users\shaniyamath\OneDrive\Documents\poppler-26.09.0\Library\bin",
    r"C:\poppler\Library\bin",
    r"C:\poppler\bin",
]


def get_poppler_path():
  for p in POPPLER_CANDIDATES:
    if os.path.exists(os.path.join(p, "pdftoppm.exe")):
      return p
  return None


POPPLER_PATH = get_poppler_path()


def pdf_bytes_to_images(
    pdf_bytes: bytes, first_page=None, last_page=None, dpi=180
):
  kwargs = {"dpi": dpi}
  if first_page is not None:
    kwargs["first_page"] = first_page
  if last_page is not None:
    kwargs["last_page"] = last_page
  if POPPLER_PATH:
    kwargs["poppler_path"] = POPPLER_PATH
  return convert_from_bytes(pdf_bytes, **kwargs)


def render_pdf_page_png(pdf_bytes: bytes, page_num_1based: int = 1, dpi: int = 180):
  try:
    images = pdf_bytes_to_images(
        pdf_bytes,
        first_page=page_num_1based,
        last_page=page_num_1based,
        dpi=dpi,
    )
    if images:
      buf = io.BytesIO()
      images[0].save(buf, format="PNG")
      buf.seek(0)
      return buf.getvalue()
  except Exception:
    pass
  return None


# ---------------- 15 DISTINCT TEMPLATE PROFILES ----------------
TEMPLATE_15_PROFILES = [
    {
        "id": 1,
        "name": "Template 01 — Classic Navy Corporate",
        "layout": "Single-Column Executive Banner",
        "texture": "Clean Crisp White Paper",
        "accent": "#0F172A",
        "secondary": "#1E293B",
        "font": "Helvetica",
        "border": True,
        "photo": False,
        "two_column": False,
    },
    {
        "id": 2,
        "name": "Template 02 — Dark Teal & Gold Sidebar Photo",
        "layout": "Two-Column Dark Teal Sidebar + Gold Section Bars",
        "texture": "Deep Teal Sidebar & White Main Canvas",
        "accent": "#134E4A",
        "secondary": "#B48A3E",
        "font": "Helvetica",
        "border": True,
        "photo": True,
        "two_column": True,
    },
    {
        "id": 3,
        "name": "Template 03 — Harvard Editorial Serif",
        "layout": "Single-Column Traditional Serif Hierarchy",
        "texture": "Classic Academic Print",
        "accent": "#1E293B",
        "secondary": "#334155",
        "font": "Times-Roman",
        "border": True,
        "photo": False,
        "two_column": False,
    },
    {
        "id": 4,
        "name": "Template 04 — Developer Mono Minimal",
        "layout": "Single-Column Compact Technical Monospace",
        "texture": "Flat Borderless Terminal",
        "accent": "#334155",
        "secondary": "#0F172A",
        "font": "Courier",
        "border": False,
        "photo": False,
        "two_column": False,
    },
    {
        "id": 5,
        "name": "Template 05 — Royal Cobalt Two-Column",
        "layout": "Two-Column Cobalt Sidebar + Clean Main Grid",
        "texture": "Corporate High-Contrast",
        "accent": "#1D4ED8",
        "secondary": "#1E40AF",
        "font": "Helvetica",
        "border": True,
        "photo": True,
        "two_column": True,
    },
    {
        "id": 6,
        "name": "Template 06 — Emerald Data & AI",
        "layout": "Single-Column Metrics-First Layout",
        "texture": "Clean Analytical White",
        "accent": "#047857",
        "secondary": "#065F46",
        "font": "Helvetica",
        "border": True,
        "photo": False,
        "two_column": False,
    },
    {
        "id": 7,
        "name": "Template 07 — Indigo Sidebar Strategy",
        "layout": "Two-Column Indigo Sidebar + Structured Sections",
        "texture": "Crisp Indigo & Slate",
        "accent": "#3730A3",
        "secondary": "#312E81",
        "font": "Helvetica",
        "border": True,
        "photo": True,
        "two_column": True,
    },
    {
        "id": 8,
        "name": "Template 08 — Crimson Leadership Serif",
        "layout": "Single-Column Executive Serif + Strong Rules",
        "texture": "Classic Print Accent",
        "accent": "#991B1B",
        "secondary": "#7F1D1D",
        "font": "Times-Roman",
        "border": True,
        "photo": False,
        "two_column": False,
    },
    {
        "id": 9,
        "name": "Template 09 — Ocean Blue Fresher Two-Column",
        "layout": "Two-Column Sky-Navy Sidebar + Projects Focus",
        "texture": "Clean Modern Fresher",
        "accent": "#0369A1",
        "secondary": "#075985",
        "font": "Helvetica",
        "border": True,
        "photo": True,
        "two_column": True,
    },
    {
        "id": 10,
        "name": "Template 10 — Monochrome Swiss Pure",
        "layout": "Single-Column Pure Black & White Typographic",
        "texture": "Borderless Swiss Minimal",
        "accent": "#000000",
        "secondary": "#18181B",
        "font": "Helvetica",
        "border": False,
        "photo": False,
        "two_column": False,
    },
    {
        "id": 11,
        "name": "Template 11 — Cyan Cloud & Systems",
        "layout": "Two-Column Cyan Sidebar + Architecture Grid",
        "texture": "Clean Cyan Accent",
        "accent": "#0E7490",
        "secondary": "#155E75",
        "font": "Helvetica",
        "border": True,
        "photo": True,
        "two_column": True,
    },
    {
        "id": 12,
        "name": "Template 12 — Bronze Consulting Profile",
        "layout": "Single-Column Impact & Outcomes Serif",
        "texture": "Editorial Bronze Tone",
        "accent": "#78350F",
        "secondary": "#92400E",
        "font": "Times-Roman",
        "border": True,
        "photo": False,
        "two_column": False,
    },
    {
        "id": 13,
        "name": "Template 13 — Plum Creative & UI Sidebar",
        "layout": "Two-Column Plum Sidebar + Portfolio Showcase",
        "texture": "Modern Creative Accent",
        "accent": "#6B21A8",
        "secondary": "#581C87",
        "font": "Helvetica",
        "border": True,
        "photo": True,
        "two_column": True,
    },
    {
        "id": 14,
        "name": "Template 14 — Carbon Automation Mono",
        "layout": "Single-Column Concise Bullet-Driven Mono",
        "texture": "Technical Carbon Style",
        "accent": "#18181B",
        "secondary": "#27272A",
        "font": "Courier",
        "border": True,
        "photo": False,
        "two_column": False,
    },
    {
        "id": 15,
        "name": "Template 15 — Logaly Signature Teal Sidebar",
        "layout": "Two-Column Signature Teal Sidebar + ATS Grid",
        "texture": "Signature Teal & Slate",
        "accent": "#0F766E",
        "secondary": "#115E59",
        "font": "Helvetica",
        "border": True,
        "photo": True,
        "two_column": True,
    },
]


def load_15_templates_from_folder_or_defaults():
  os.makedirs(TEMPLATES_15_DIR, exist_ok=True)
  image_files = sorted([
      f
      for f in os.listdir(TEMPLATES_15_DIR)
      if f.lower().endswith((".png", ".jpg", ".jpeg", ".webp"))
  ])

  trained_map = {}
  if os.path.exists(TRAINED_15_JSON):
    try:
      saved = json.load(open(TRAINED_15_JSON, "r", encoding="utf-8"))
      for item in saved.get("templates", []):
        trained_map[item.get("id")] = item
    except Exception:
      pass

  catalog = []
  for idx, base_tpl in enumerate(TEMPLATE_15_PROFILES):
    t_id = idx + 1
    img_path = (
        os.path.join(TEMPLATES_15_DIR, image_files[idx])
        if idx < len(image_files)
        else None
    )
    ocr_summary = ""
    detected_two_col = base_tpl["two_column"]
    detected_photo = base_tpl["photo"]

    if img_path and os.path.exists(img_path):
      try:
        ocr_summary = re.sub(
            r"\s+", " ", pytesseract.image_to_string(img_path)
        ).strip()[:700]
        upper_ocr = ocr_summary.upper()
        if any(
            k in upper_ocr
            for k in ["LANGUAGES", "HOBBIES", "CONTACT", "SKILLS", "PROFILE"]
        ):
          detected_two_col = True
        if any(
            k in upper_ocr
            for k in ["HOBBIES", "LANGUAGES", "ABOUT ME", "CREATIVE", "DESIGNER"]
        ):
          detected_photo = True
      except Exception:
        ocr_summary = ""

    saved_info = trained_map.get(t_id, {})
    catalog.append({
        **base_tpl,
        "image_path": img_path,
        "two_column": saved_info.get("two_column", detected_two_col),
        "photo": saved_info.get("photo", detected_photo),
        "ocr_summary": saved_info.get("ocr_summary") or ocr_summary,
        "trained_rules": saved_info.get("trained_rules")
        or f"Follow {base_tpl['name']} strictly: layout='{base_tpl['layout']}', "
        f"texture='{base_tpl['texture']}', accent='{base_tpl['accent']}', font='{base_tpl['font']}'.",
    })
  return catalog


# ---------------- CORE AI & PDF HELPERS ----------------
def call_ai(system_prompt: str, user_prompt: str) -> str:
  try:
    response = client.responses.create(
        model=MODEL_NAME,
        input=f"SYSTEM INSTRUCTIONS:\n{system_prompt}\n\nUSER REQUEST:\n{user_prompt}",
        store=True,
    )
    return response.output_text
  except Exception as e:
    return f"⚠️ API Error: {e}"


def extract_pdf_data(uploaded_file):
  if uploaded_file is None:
    return "", {}

  pdf_text = ""
  structure_meta = {
      "page_count": 1,
      "has_borders": False,
      "linkedin": "",
      "github": "",
      "has_image": False,
      "font_style": "Helvetica",
  }

  try:
    uploaded_file.seek(0)
    with pdfplumber.open(uploaded_file) as pdf:
      structure_meta["page_count"] = len(pdf.pages)
      for page in pdf.pages:
        if len(page.images) > 0:
          structure_meta["has_image"] = True
        if len(page.rects) > 0 or len(page.lines) > 2:
          structure_meta["has_borders"] = True
        if page.hyperlinks:
          for link in page.hyperlinks:
            uri = link.get("uri", "")
            if uri:
              if "linkedin.com" in uri.lower():
                structure_meta["linkedin"] = uri
              elif "github.com" in uri.lower():
                structure_meta["github"] = uri
        if page.chars:
          fontname = page.chars[0].get("fontname", "")
          if "Times" in fontname or "Serif" in fontname:
            structure_meta["font_style"] = "Times-Roman"
          elif "Courier" in fontname or "Mono" in fontname:
            structure_meta["font_style"] = "Courier"
  except Exception:
    pass

  try:
    uploaded_file.seek(0)
    reader = PdfReader(uploaded_file)
    for page in reader.pages:
      txt = page.extract_text()
      if txt:
        pdf_text += txt + "\n"
  except Exception:
    pass

  if not pdf_text.strip():
    try:
      uploaded_file.seek(0)
      images = pdf_bytes_to_images(uploaded_file.read(), dpi=180)
      for img in images:
        pdf_text += pytesseract.image_to_string(img) + "\n"
    except Exception as e:
      st.error(f"OCR Error: {e}")

  if not structure_meta["linkedin"]:
    m = re.search(
        r"(https?://(?:www\.)?linkedin\.com/in/[A-Za-z0-9_-]+)", pdf_text
    )
    if m:
      structure_meta["linkedin"] = m.group(1)
  if not structure_meta["github"]:
    m = re.search(r"(https?://(?:www\.)?github\.com/[A-Za-z0-9_-]+)", pdf_text)
    if m:
      structure_meta["github"] = m.group(1)

  return pdf_text.strip(), structure_meta


def extract_score(text: str, current_score=None):
  if not text:
    return current_score
  patterns = [
      r"(?:ATS\s*(?:Match\s*)?Score[:\s*-]*)\**(\d{1,3})\s*(?:/\s*100|%)",
      r"\b(\d{1,3})\s*/\s*100\b",
      r"\b(\d{1,3})\s*%\s*(?:ATS|match|score)?",
  ]
  for pat in patterns:
    m = re.search(pat, text, flags=re.IGNORECASE)
    if m:
      val = int(m.group(1))
      if 0 <= val <= 100:
        return val
  return current_score


def refresh_combined_analysis():
  q = st.session_state.get("quick_scan_res", "").strip()
  d = st.session_state.get("detailed_res", "").strip()
  a = st.session_state.get("ats_opt_res", "").strip()
  parts = []
  if q:
    parts.append(f"### 1. Quick Scan\n{q}")
  if d:
    parts.append(f"### 2. Detailed Analysis\n{d}")
  if a:
    parts.append(f"### 3. ATS Optimization\n{a}")
  st.session_state["combined_analysis"] = "\n\n---\n\n".join(parts)


def get_active_analysis_context() -> str:
  refresh_combined_analysis()
  return st.session_state.get("combined_analysis", "")


def _clean_markdown_lines(resume_markdown: str):
  cleaned = []
  for raw in resume_markdown.splitlines():
    s = raw.strip()
    if not s or s in ("---", "***", "___", "==="):
      continue
    cleaned.append(s)
  return cleaned


def _parse_resume_sections(resume_markdown: str):
  """Splits generated resume markdown into header info and ordered sections."""
  name = "CANDIDATE NAME"
  contact_lines = []
  sections = []
  current_title = "PROFESSIONAL SUMMARY"
  current_items = []

  lines = _clean_markdown_lines(resume_markdown)
  header_parsed = False

  for line in lines:
    if line.startswith("# ") and not header_parsed:
      name = line.replace("# ", "").replace("**", "").strip()
      header_parsed = True
    elif line.startswith("## ") or line.startswith("### "):
      if current_items:
        sections.append((current_title, current_items))
      current_title = (
          line.replace("### ", "").replace("## ", "").replace("**", "").strip()
      )
      current_items = []
    else:
      cleaned = line.replace("**", "").strip()
      if not sections and not current_items and len(contact_lines) < 2 and (
          "@" in cleaned
          or "linkedin.com" in cleaned.lower()
          or "github.com" in cleaned.lower()
          or "|" in cleaned
      ):
        contact_lines.append(cleaned)
      else:
        current_items.append(cleaned)

  if current_items:
    sections.append((current_title, current_items))

  return name, " | ".join(contact_lines), sections


def _build_single_page_pdf_pass(
    resume_markdown: str,
    accent_hex: str,
    secondary_hex: str,
    font_family: str,
    use_border: bool,
    photo_bytes: bytes,
    font_size: float,
    leading_size: float,
    margin_pts: float,
    max_lines: int = None,
    two_column_layout: bool = False,
) -> bytes:
  buffer = io.BytesIO()
  doc = SimpleDocTemplate(
      buffer,
      pagesize=A4,
      rightMargin=margin_pts,
      leftMargin=margin_pts,
      topMargin=margin_pts,
      bottomMargin=margin_pts,
  )
  styles = getSampleStyleSheet()
  accent_color = colors.HexColor(accent_hex)
  secondary_color = colors.HexColor(secondary_hex)
  bold_font = (
      "Times-Bold" if font_family == "Times-Roman" else f"{font_family}-Bold"
  )

  title_style = ParagraphStyle(
      "ResumeTitle",
      parent=styles["Heading1"],
      fontName=bold_font,
      fontSize=font_size + 6.5,
      leading=font_size + 8.5,
      textColor=accent_color,
      spaceAfter=2,
  )
  heading_style = ParagraphStyle(
      "SectionHeading",
      parent=styles["Heading2"],
      fontName=bold_font,
      fontSize=font_size + 1.5,
      leading=font_size + 3.4,
      textColor=accent_color,
      spaceBefore=4,
      spaceAfter=2,
  )
  body_style = ParagraphStyle(
      "ResumeBody",
      parent=styles["Normal"],
      fontName=font_family,
      fontSize=font_size,
      leading=leading_size,
      textColor=colors.HexColor("#111827"),
      spaceAfter=1.4,
  )
  sidebar_heading_style = ParagraphStyle(
      "SidebarHeading",
      parent=styles["Heading2"],
      fontName=bold_font,
      fontSize=max(font_size + 0.5, 7.5),
      leading=leading_size,
      textColor=colors.HexColor("#FFFFFF"),
      spaceBefore=5,
      spaceAfter=2,
  )
  sidebar_body_style = ParagraphStyle(
      "SidebarBody",
      parent=styles["Normal"],
      fontName=font_family,
      fontSize=max(font_size - 0.3, 6.8),
      leading=max(leading_size - 0.6, 8.2),
      textColor=colors.HexColor("#F1F5F9"),
      spaceAfter=1.2,
  )

  raw_lines = _clean_markdown_lines(resume_markdown)
  if max_lines is not None:
    raw_lines = raw_lines[:max_lines]
  filtered_md = "\n".join(raw_lines)

  story = []

  if two_column_layout or photo_bytes:
    name, contact_str, sections = _parse_resume_sections(filtered_md)
    left_w = doc.width * 0.33
    right_w = doc.width * 0.67

    left_flow = []
    if photo_bytes:
      try:
        img_reader = ImageReader(io.BytesIO(photo_bytes))
        left_flow.append(RLImage(img_reader, width=62, height=62))
        left_flow.append(Spacer(1, 4))
      except Exception:
        pass

    if contact_str:
      left_flow.append(Paragraph("CONTACT & LINKS", sidebar_heading_style))
      for part in [p.strip() for p in contact_str.split("|") if p.strip()]:
        left_flow.append(Paragraph(part, sidebar_body_style))

    sidebar_keys = (
        "SKILL",
        "LANGUAGE",
        "HOBB",
        "INTEREST",
        "TOOL",
        "CERTIF",
    )
    main_flow = [
        Paragraph(name.upper(), title_style),
        HRFlowable(
            width="100%",
            thickness=1.4,
            color=secondary_color,
            spaceBefore=1,
            spaceAfter=4,
        ),
    ]

    for sec_title, sec_items in sections:
      if any(k in sec_title.upper() for k in sidebar_keys):
        left_flow.append(Paragraph(sec_title.upper(), sidebar_heading_style))
        for item in sec_items[:9]:
          bullet_txt = (
              f"• {item[2:]}" if item.startswith(("- ", "* ")) else f"• {item}"
          )
          left_flow.append(Paragraph(bullet_txt, sidebar_body_style))
      else:
        # Pill/bar accent header matching sidebar templates
        pill_tbl = Table(
            [[
                Paragraph(
                    f"<font color='#FFFFFF'><b>{sec_title.upper()}</b></font>",
                    heading_style,
                )
            ]],
            colWidths=[right_w - 18],
        )
        pill_tbl.setStyle(
            TableStyle([
                ("BACKGROUND", (0, 0), (0, 0), secondary_color),
                ("LEFTPADDING", (0, 0), (0, 0), 6),
                ("RIGHTPADDING", (0, 0), (0, 0), 6),
                ("TOPPADDING", (0, 0), (0, 0), 2),
                ("BOTTOMPADDING", (0, 0), (0, 0), 2),
            ])
        )
        main_flow.append(Spacer(1, 3))
        main_flow.append(pill_tbl)
        main_flow.append(Spacer(1, 2))
        for item in sec_items:
          if item.startswith(("- ", "* ")):
            main_flow.append(Paragraph(f"• {item[2:]}", body_style))
          else:
            main_flow.append(Paragraph(item, body_style))

    grid = Table(
        [[left_flow, main_flow]],
        colWidths=[left_w, right_w],
    )
    grid.setStyle(
        TableStyle([
            ("BACKGROUND", (0, 0), (0, 0), accent_color),
            ("BACKGROUND", (1, 0), (1, 0), colors.HexColor("#FFFFFF")),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LEFTPADDING", (0, 0), (0, 0), 8),
            ("RIGHTPADDING", (0, 0), (0, 0), 8),
            ("TOPPADDING", (0, 0), (0, 0), 8),
            ("BOTTOMPADDING", (0, 0), (0, 0), 8),
            ("LEFTPADDING", (1, 0), (1, 0), 10),
            ("RIGHTPADDING", (1, 0), (1, 0), 8),
            ("TOPPADDING", (1, 0), (1, 0), 6),
            ("BOTTOMPADDING", (1, 0), (1, 0), 6),
        ])
    )
    story.append(grid)
  else:
    first_heading_done = False
    for line in raw_lines:
      clean_line = (
          line.replace("**", "")
          .replace("### ", "")
          .replace("## ", "")
          .replace("# ", "")
      )
      if line.startswith("# ") and not first_heading_done:
        story.append(Paragraph(clean_line, title_style))
        if use_border:
          story.append(
              HRFlowable(
                  width="100%",
                  thickness=1.3,
                  color=accent_color,
                  spaceBefore=1,
                  spaceAfter=4,
              )
          )
        first_heading_done = True
      elif line.startswith("## ") or line.startswith("### ") or line.isupper():
        story.append(Paragraph(clean_line, heading_style))
        if use_border:
          story.append(
              HRFlowable(
                  width="100%",
                  thickness=0.75,
                  color=accent_color,
                  spaceBefore=1,
                  spaceAfter=2,
              )
          )
      elif line.startswith("- ") or line.startswith("* "):
        story.append(Paragraph(f"• {clean_line[2:]}", body_style))
      else:
        story.append(Paragraph(clean_line, body_style))

  doc.build(story)
  buffer.seek(0)
  return buffer.read()


def build_resume_pdf(
    resume_markdown: str,
    accent_hex: str = "#0F172A",
    secondary_hex: str = "#1E293B",
    font_family: str = "Helvetica",
    use_border: bool = True,
    photo_bytes: bytes = None,
    two_column_layout: bool = False,
) -> bytes:
  """Fits content cleanly onto ONE single A4 page across all templates."""
  candidates = [
      (9.2, 11.6, 22),
      (8.5, 10.8, 20),
      (7.8, 10.0, 18),
      (7.2, 9.2, 16),
      (6.7, 8.5, 14),
  ]
  last_pdf = None
  for f_sz, lead_sz, marg in candidates:
    pdf_out = _build_single_page_pdf_pass(
        resume_markdown,
        accent_hex,
        secondary_hex,
        font_family,
        use_border,
        photo_bytes,
        f_sz,
        lead_sz,
        marg,
        two_column_layout=two_column_layout,
    )
    last_pdf = pdf_out
    if len(PdfReader(io.BytesIO(pdf_out)).pages) == 1:
      return pdf_out

  non_empty_lines = _clean_markdown_lines(resume_markdown)
  for trim_n in range(len(non_empty_lines) - 1, 8, -1):
    pdf_out = _build_single_page_pdf_pass(
        resume_markdown,
        accent_hex,
        secondary_hex,
        font_family,
        use_border,
        photo_bytes,
        6.7,
        8.5,
        14,
        max_lines=trim_n,
        two_column_layout=two_column_layout,
    )
    if len(PdfReader(io.BytesIO(pdf_out)).pages) == 1:
      return pdf_out

  return last_pdf


def load_feedback():
  if os.path.exists(FEEDBACK_DB_PATH):
    try:
      with open(FEEDBACK_DB_PATH, "r", encoding="utf-8") as f:
        return json.load(f)
    except Exception:
      return []
  return []


def save_feedback(data):
  with open(FEEDBACK_DB_PATH, "w", encoding="utf-8") as f:
    json.dump(data, f, indent=2)


# ---------------- PAGE CONFIG & SESSION STATE ----------------
st.set_page_config(
    page_title="Logaly | AI Career & ATS Suite",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded",
)

for key, default in {
    "pdf_text": "",
    "structure_meta": {},
    "file_name": "",
    "job_description": "",
    "target_role": "",
    "quick_scan_res": "",
    "detailed_res": "",
    "ats_opt_res": "",
    "combined_analysis": "",
    "ats_score": None,
    "interview_history": [],
    "interview_active": False,
    "voted_reviews": [],
    "sound_enabled": True,
    "templates_15": [],
    "tpl15_idx": 0,
}.items():
  if key not in st.session_state:
    st.session_state[key] = default

if not st.session_state["templates_15"]:
  st.session_state["templates_15"] = load_15_templates_from_folder_or_defaults()

# ---------------- OBSIDIAN BLACK THEME + MOUSE & GRAPH INTERACTION + SOUND FX ----------------
st.markdown(
    """
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

    :root {
        --mouse-x: 50vw;
        --mouse-y: 50vh;
    }

    .stApp {
        background-color: #05070A;
        color: #F8FAFC;
        font-family: 'Inter', sans-serif;
    }

    .stApp::after {
        content: "";
        position: fixed;
        inset: 0;
        background: radial-gradient(
            560px circle at var(--mouse-x) var(--mouse-y),
            rgba(20, 184, 166, 0.16),
            transparent 72%
        );
        pointer-events: none;
        z-index: 1;
    }

    .stApp::before {
        content: "";
        position: fixed;
        inset: 0;
        background-image: radial-gradient(rgba(45, 212, 191, 0.08) 1px, transparent 1px);
        background-size: 24px 24px;
        pointer-events: none;
        z-index: 0;
    }

    @keyframes fadeSlideUp {
        from { opacity: 0; transform: translateY(14px); }
        to { opacity: 1; transform: translateY(0); }
    }

    @keyframes pulseTeal {
        0%, 100% { box-shadow: 0 0 14px rgba(20, 184, 166, 0.22); }
        50% { box-shadow: 0 0 28px rgba(20, 184, 166, 0.55); }
    }

    .logaly-banner {
        background: linear-gradient(135deg, #0B0E14 0%, #111622 100%);
        border: 1px solid #1E293B;
        border-radius: 16px;
        padding: 1.35rem 2rem;
        margin-bottom: 1.35rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
        animation: fadeSlideUp 0.5s ease-out;
        transition: transform 0.22s ease, border-color 0.22s ease, box-shadow 0.22s ease;
    }
    .logaly-banner:hover {
        border-color: #14B8A6;
        transform: translateY(-2px);
        box-shadow: 0 10px 28px rgba(20, 184, 166, 0.18);
    }
    .logaly-logo {
        font-size: 1.9rem;
        font-weight: 800;
        background: linear-gradient(90deg, #FFFFFF 0%, #2DD4BF 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin: 0;
    }
    .logaly-tagline {
        color: #94A3B8;
        font-size: 0.9rem;
        margin: 0.2rem 0 0 0;
    }
    .engine-pill {
        background: rgba(20, 184, 166, 0.12);
        border: 1px solid rgba(45, 212, 191, 0.45);
        color: #2DD4BF;
        padding: 0.42rem 0.95rem;
        border-radius: 999px;
        font-size: 0.8rem;
        font-weight: 600;
        animation: pulseTeal 3s infinite;
    }

    div[data-testid="stVerticalBlockBorderWrapper"] {
        background-color: #0B0E14 !important;
        border: 1px solid #1E293B !important;
        border-radius: 14px !important;
        padding: 1.25rem !important;
        transition: transform 0.18s cubic-bezier(0.22, 1, 0.36, 1),
                    border-color 0.22s ease,
                    box-shadow 0.22s ease !important;
        animation: fadeSlideUp 0.45s ease-out;
    }
    div[data-testid="stVerticalBlockBorderWrapper"]:hover {
        border-color: #14B8A6 !important;
        box-shadow: 0 12px 30px rgba(20, 184, 166, 0.18) !important;
    }

    section[data-testid="stSidebar"] {
        background-color: #040507 !important;
        border-right: 1px solid #1E293B;
    }

    .stTextArea textarea, .stTextInput input, div[data-baseweb="select"] > div {
        background-color: #06080C !important;
        color: #F8FAFC !important;
        border: 1px solid #263042 !important;
        border-radius: 10px !important;
    }
    .stTextArea textarea:focus, .stTextInput input:focus {
        border-color: #14B8A6 !important;
        box-shadow: 0 0 0 2px rgba(20, 184, 166, 0.25) !important;
    }

    section[data-testid="stFileUploaderDropzone"] {
        background-color: #080B10 !important;
        border: 1.5px dashed #14B8A6 !important;
        border-radius: 12px !important;
    }

    div.stButton > button {
        background: linear-gradient(90deg, #0D9488 0%, #14B8A6 100%) !important;
        color: #042F2E !important;
        font-weight: 700 !important;
        border: none !important;
        border-radius: 10px !important;
        padding: 0.65rem 1.4rem !important;
        transition: transform 0.18s ease, box-shadow 0.22s ease, color 0.18s ease !important;
    }
    div.stButton > button:hover {
        transform: translateY(-2px) scale(1.01);
        box-shadow: 0 0 24px rgba(20, 184, 166, 0.58) !important;
        color: #FFFFFF !important;
    }

    div[data-testid="stMetric"] {
        background-color: #0B0E14;
        border: 1px solid #1E293B;
        border-radius: 12px;
        padding: 0.9rem;
        transition: transform 0.18s ease, border-color 0.2s ease, box-shadow 0.2s ease;
    }
    div[data-testid="stMetric"]:hover {
        transform: translateY(-3px);
        border-color: #2DD4BF;
        box-shadow: 0 8px 22px rgba(20, 184, 166, 0.18);
    }
    div[data-testid="stMetricValue"] {
        color: #2DD4BF !important;
    }
</style>
""",
    unsafe_allow_html=True,
)

sound_flag = "true" if st.session_state["sound_enabled"] else "false"
components.html(
    f"""
<script>
(function() {{
    const parentDoc = window.parent.document;
    const parentWin = window.parent;
    parentWin.__logalySoundEnabled = {sound_flag};

    function playUiTone(freq, duration, type, gainVal) {{
        if (!parentWin.__logalySoundEnabled) return;
        try {{
            const AudioCtx = parentWin.AudioContext || parentWin.webkitAudioContext;
            if (!parentWin.__logalyAudioCtx) {{
                parentWin.__logalyAudioCtx = new AudioCtx();
            }}
            const ctx = parentWin.__logalyAudioCtx;
            if (ctx.state === 'suspended') {{
                ctx.resume();
            }}
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = type || 'sine';
            osc.frequency.setValueAtTime(freq, ctx.currentTime);
            gain.gain.setValueAtTime(gainVal || 0.03, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start();
            osc.stop(ctx.currentTime + duration);
        }} catch (err) {{}}
    }}

    if (!parentDoc.getElementById('logaly-interactive-engine')) {{
        const marker = parentDoc.createElement('div');
        marker.id = 'logaly-interactive-engine';
        parentDoc.body.appendChild(marker);

        let lastHoverTime = 0;
        parentDoc.addEventListener('mousemove', (e) => {{
            parentDoc.documentElement.style.setProperty('--mouse-x', e.clientX + 'px');
            parentDoc.documentElement.style.setProperty('--mouse-y', e.clientY + 'px');

            const cards = parentDoc.querySelectorAll('div[data-testid="stVerticalBlockBorderWrapper"], div[data-testid="stMetric"]');
            cards.forEach(card => {{
                const rect = card.getBoundingClientRect();
                if (
                    e.clientX >= rect.left && e.clientX <= rect.right &&
                    e.clientY >= rect.top && e.clientY <= rect.bottom
                ) {{
                    const x = (e.clientX - rect.left) / rect.width - 0.5;
                    const y = (e.clientY - rect.top) / rect.height - 0.5;
                    card.style.transform = `perspective(1000px) rotateX(${{(-y * 2.2).toFixed(2)}}deg) rotateY(${{(x * 2.2).toFixed(2)}}deg) translateY(-2px)`;
                }} else {{
                    card.style.transform = '';
                }}
            }});
        }});

        parentDoc.addEventListener('mouseover', (e) => {{
            const btn = e.target.closest('button');
            const now = Date.now();
            if (btn && now - lastHoverTime > 90) {{
                lastHoverTime = now;
                playUiTone(540, 0.045, 'triangle', 0.025);
            }}
        }});

        parentDoc.addEventListener('click', (e) => {{
            const btn = e.target.closest('button');
            if (btn) {{
                playUiTone(760, 0.08, 'sine', 0.045);
            }}
        }});
    }}
}})();
</script>
""",
    height=0,
)

# ---------------- TOP HEADER ----------------
st.markdown(
    """
<div class="logaly-banner">
    <div>
        <h1 class="logaly-logo">🔍 Logaly</h1>
        <p class="logaly-tagline">Obsidian Mouse-Reactive UI • Sound FX • 15 Template Architectures • Single-Page Resume Generator</p>
    </div>
    <div class="engine-pill">● Engine: gpt-6-luna</div>
</div>
""",
    unsafe_allow_html=True,
)

# ---------------- LEFT NAVIGATION PANEL (7 FEATURES) ----------------
with st.sidebar:
  st.markdown("## 🧭 Logaly Navigation")
  nav_choice = st.radio(
      "Choose Feature",
      [
          "1. Resume & Role Input",
          "2. Resume Implementation",
          "3. Resume-to-Company Matcher",
          "4. Career Roadmap",
          "5. Skill Gap Analyzer",
          "6. Interview Preparation",
          "7. Feedback",
      ],
      label_visibility="collapsed",
  )

  st.markdown("---")
  sound_toggle = st.checkbox(
      "🔊 UI Sound Effects", value=st.session_state["sound_enabled"]
  )
  st.session_state["sound_enabled"] = sound_toggle

  if st.session_state["pdf_text"]:
    st.success(f"📄 Resume Loaded:\n**{st.session_state['file_name']}**")
  else:
    st.info("Upload your PDF resume in **1. Resume & Role Input**.")

# ==============================================================================
# FEATURE 1: RESUME & ROLE INPUT + LIVE INTELLIGENCE DASHBOARD BELOW IT
# ==============================================================================
if nav_choice == "1. Resume & Role Input":
  st.markdown("## 1️⃣ Resume & Role Input")

  with st.container(border=True):
    upload_file = st.file_uploader(
        "Drag and drop your resume (PDF)",
        type=["pdf"],
        key="main_resume_pdf_uploader",
    )

    target_role_input = st.text_input(
        "Target Role",
        value=st.session_state["target_role"],
        placeholder="e.g., Python Developer, AI Engineer, Data Analyst",
    )

    job_desc_input = st.text_area(
        "Target Job Description (Optional)",
        value=st.session_state["job_description"],
        height=140,
        placeholder="Paste the job description here...",
    )

    run_combined_btn = st.button(
        "⚡ Run Combined (Quick Scan + Detailed Analysis + ATS Optimization)",
        use_container_width=True,
    )
    b_q, b_d, b_a = st.columns(3)
    run_quick_btn = b_q.button("1. Quick Scan", use_container_width=True)
    run_detail_btn = b_d.button("2. Detailed Analysis", use_container_width=True)
    run_ats_btn = b_a.button("3. ATS Optimization", use_container_width=True)

  if run_combined_btn or run_quick_btn or run_detail_btn or run_ats_btn:
    if upload_file is None and not st.session_state["pdf_text"]:
      st.error("Please upload a PDF resume first.")
    else:
      if upload_file is not None:
        with st.spinner("Extracting text and resume structure..."):
          txt, meta = extract_pdf_data(upload_file)
          if not txt:
            st.error("No text could be extracted from this PDF.")
            st.stop()
          st.session_state["pdf_text"] = txt
          st.session_state["structure_meta"] = meta
          st.session_state["file_name"] = upload_file.name

      st.session_state["job_description"] = job_desc_input
      st.session_state["target_role"] = target_role_input
      pdf_text = st.session_state["pdf_text"]

      quick_prompt = f"""
Perform **Quick Scan**:
- Basic resume details (contact, LinkedIn/GitHub, education, experience level)
- Skills, projects, and suitable job roles
- Basic ATS issues
- ATS Score out of 100

Target Role: {target_role_input}
Job Description: {job_desc_input}
Resume:
{pdf_text}
"""
      detailed_prompt = f"""
Perform **Detailed Analysis**:
- Strengths & weaknesses
- Missing skills & experience gaps
- Formatting/structural problems
- Areas for improvement & section ratings

Target Role: {target_role_input}
Job Description: {job_desc_input}
Resume:
{pdf_text}
"""
      ats_prompt = f"""
Perform **ATS Optimization**:
- Missing job keywords
- ATS formatting issues
- Skill mismatches
- Suggested keywords & bullet optimizations to improve ATS compatibility
- ATS Score out of 100

Target Role: {target_role_input}
Job Description: {job_desc_input}
Resume:
{pdf_text}
"""

      if run_combined_btn:
        with st.spinner(
            "Running Quick Scan, Detailed Analysis & ATS Optimization..."
        ):
          q_out = call_ai(
              "You are an expert ATS Quick Scan specialist.", quick_prompt
          )
          d_out = call_ai(
              "You are an expert Resume & Skill Evaluator.", detailed_prompt
          )
          a_out = call_ai(
              "You are an expert ATS Keyword & Formatting Specialist.", ats_prompt
          )
          st.session_state["quick_scan_res"] = q_out
          st.session_state["detailed_res"] = d_out
          st.session_state["ats_opt_res"] = a_out
          st.session_state["ats_score"] = extract_score(
              a_out, extract_score(q_out, st.session_state["ats_score"])
          )
      elif run_quick_btn:
        with st.spinner("Running Quick Scan..."):
          q_out = call_ai(
              "You are an expert ATS Quick Scan specialist.", quick_prompt
          )
          st.session_state["quick_scan_res"] = q_out
          st.session_state["ats_score"] = extract_score(
              q_out, st.session_state["ats_score"]
          )
      elif run_detail_btn:
        with st.spinner("Running Detailed Analysis..."):
          d_out = call_ai(
              "You are an expert Resume & Skill Evaluator.", detailed_prompt
          )
          st.session_state["detailed_res"] = d_out
      elif run_ats_btn:
        with st.spinner("Running ATS Optimization..."):
          a_out = call_ai(
              "You are an expert ATS Keyword & Formatting Specialist.", ats_prompt
          )
          st.session_state["ats_opt_res"] = a_out
          st.session_state["ats_score"] = extract_score(
              a_out, st.session_state["ats_score"]
          )

      refresh_combined_analysis()

  st.markdown("---")
  st.markdown("## 📊 Live Intelligence Dashboard")

  refresh_combined_analysis()
  if st.session_state["combined_analysis"]:
    score_val = st.session_state["ats_score"]
    meta = st.session_state["structure_meta"]

    g_col, m1, m2, m3 = st.columns([1.15, 1, 1, 1])
    with g_col:
      dash_offset = (
          314 - (314 * score_val / 100) if score_val is not None else 314
      )
      score_label = f"{score_val}%" if score_val is not None else "N/A"
      components.html(
          f"""
            <div id="ats-ring-card" style="
                background:#0B0E14;
                border:1px solid #1E293B;
                border-radius:14px;
                padding:12px;
                text-align:center;
                font-family:Inter,sans-serif;
                color:white;
                transition: transform 0.16s ease, border-color 0.2s ease, box-shadow 0.2s ease;
                cursor:pointer;
            ">
                <div style="font-size:12px; color:#94A3B8; font-weight:700;">ATS SCORE</div>
                <svg id="ats-ring-svg" width="118" height="118" viewBox="0 0 120 120" style="transition: transform 0.22s ease;">
                    <circle cx="60" cy="60" r="50" fill="none" stroke="#1E293B" stroke-width="10"/>
                    <circle cx="60" cy="60" r="50" fill="none" stroke="#14B8A6" stroke-width="10"
                        stroke-dasharray="314"
                        stroke-dashoffset="{dash_offset}"
                        stroke-linecap="round"
                        transform="rotate(-90 60 60)"/>
                    <text x="60" y="67" text-anchor="middle" fill="#FFFFFF" font-size="22" font-weight="800">{score_label}</text>
                </svg>
            </div>
            <script>
            (function() {{
                const card = document.getElementById('ats-ring-card');
                const svg = document.getElementById('ats-ring-svg');
                if (!card || !svg) return;
                card.addEventListener('mousemove', (e) => {{
                    const r = card.getBoundingClientRect();
                    const nx = (e.clientX - r.left) / r.width - 0.5;
                    const ny = (e.clientY - r.top) / r.height - 0.5;
                    card.style.borderColor = '#2DD4BF';
                    card.style.boxShadow = '0 10px 26px rgba(20, 184, 166, 0.28)';
                    card.style.transform = `perspective(700px) rotateX(${{(-ny * 14).toFixed(2)}}deg) rotateY(${{(nx * 14).toFixed(2)}}deg) scale(1.03)`;
                    svg.style.transform = `scale(1.08) rotate(${{(nx * 12).toFixed(1)}}deg)`;
                }});
                card.addEventListener('mouseleave', () => {{
                    card.style.borderColor = '#1E293B';
                    card.style.boxShadow = 'none';
                    card.style.transform = '';
                    svg.style.transform = '';
                }});
            }})();
            </script>
            """,
          height=168,
      )
    with m1:
      st.metric("Characters", f"{len(st.session_state['pdf_text']):,}")
      st.metric("Borders", "Yes" if meta.get("has_borders") else "No")
    with m2:
      st.metric("LinkedIn", "Detected" if meta.get("linkedin") else "Not Found")
      st.metric("GitHub", "Detected" if meta.get("github") else "Not Found")
    with m3:
      st.metric("Font Style", meta.get("font_style", "Helvetica"))
      st.metric("Image / Photo", "Yes" if meta.get("has_image") else "No")

    t_comb, t1, t2, t3 = st.tabs([
        "🧩 All 3 Combined (Active Across All Sections)",
        "1. Quick Scan",
        "2. Detailed Analysis",
        "3. ATS Optimization",
    ])
    with t_comb:
      with st.container(border=True):
        st.markdown(st.session_state["combined_analysis"])
    with t1:
      with st.container(border=True):
        st.markdown(
            st.session_state["quick_scan_res"] or "_Quick Scan not run yet._"
        )
    with t2:
      with st.container(border=True):
        st.markdown(
            st.session_state["detailed_res"]
            or "_Detailed Analysis not run yet._"
        )
    with t3:
      with st.container(border=True):
        st.markdown(
            st.session_state["ats_opt_res"] or "_ATS Optimization not run yet._"
        )
  else:
    with st.container(border=True):
      st.info(
          "Your **Live Intelligence Dashboard** appears right here below the upload & analysis form once you run an analysis."
      )

# ==============================================================================
# FEATURE 2: RESUME IMPLEMENTATION (15 DISTINCT TEMPLATES + SINGLE-PAGE PDF)
# ==============================================================================
elif nav_choice == "2. Resume Implementation":
  st.markdown("## 2️⃣ Resume Implementation (Single-Page Full-Space PDFs)")

  if not st.session_state["pdf_text"]:
    st.warning("Upload your resume in **1. Resume & Role Input** first.")
    st.stop()

  meta = st.session_state["structure_meta"]
  combined_ctx = get_active_analysis_context()

  tab_k1, tab_k2_roles, tab_k2_15 = st.tabs([
      "Kind 1: Same Structure Upgraded (1-Page PDF)",
      "Kind 2A: 3–4 Role Resumes (1-Page PDF)",
      "Kind 2B: 15 Trained Templates (Matched Layout + 1-Page PDF)",
  ])

  with tab_k1:
    with st.container(border=True):
      st.markdown("### Implement Improvements Keeping Your Exact Structure (1 Page)")
      k1_color = st.color_picker("Accent / Heading Color", "#0F172A")
      if st.button("✨ Generate Single-Page Upgraded Resume (.pdf)"):
        with st.spinner("Generating single-page upgraded resume..."):
          k1_md = call_ai(
              "You are an expert ATS Resume Architect. Keep the user's exact structure, sections, LinkedIn/GitHub links, and truthful facts while fixing weaknesses and adding missing ATS keywords. Keep content concise and complete so it fits onto ONE single page without trailing blank space. Do not output '---' horizontal rule lines. Use '# Name' and '## SECTION' headings.",
              f"Combined Analysis:\n{combined_ctx}\n\nOriginal Resume:\n{st.session_state['pdf_text']}",
          )
          st.session_state["k1_md"] = k1_md
          st.session_state["k1_pdf"] = build_resume_pdf(
              k1_md,
              accent_hex=k1_color,
              secondary_hex=k1_color,
              font_family=meta.get("font_style", "Helvetica"),
              use_border=meta.get("has_borders", True),
              two_column_layout=False,
          )
      if "k1_md" in st.session_state:
        st.markdown(st.session_state["k1_md"])
        st.download_button(
            "📥 Download Single-Page Kind 1 Resume (.pdf)",
            data=st.session_state["k1_pdf"],
            file_name="Logaly_Kind1_1Page.pdf",
            mime="application/pdf",
        )

  with tab_k2_roles:
    with st.container(border=True):
      st.markdown("### Generate 3–4 Role-Based Resumes (1 Page Each)")
      count_roles = st.slider("Select number of role resumes", 3, 4, 3)
      if st.button("🚀 Generate Single-Page Role-Tailored PDFs"):
        with st.spinner("Creating single-page role-specific resumes..."):
          raw_roles = call_ai(
              f"List {count_roles} suitable job roles for this resume, one per line, plain text only.",
              f"Combined Analysis:\n{combined_ctx}\n\nResume:\n{st.session_state['pdf_text']}",
          )
          roles_list = [
              r.strip("-•*1234. ")
              for r in raw_roles.splitlines()
              if r.strip()
          ][:count_roles]
          out_list = []
          for r_title in roles_list:
            md_txt = call_ai(
                f"Tailor this resume for {r_title} while keeping original structure, LinkedIn/GitHub links, and truthful facts. Keep concise for a strict ONE-PAGE resume. Do not output '---' lines. Use '# Name' and '## SECTION'.",
                f"Combined Analysis:\n{combined_ctx}\n\nResume:\n{st.session_state['pdf_text']}",
            )
            pdf_b = build_resume_pdf(
                md_txt,
                accent_hex="#1E3A8A",
                secondary_hex="#1E40AF",
                font_family=meta.get("font_style", "Helvetica"),
                use_border=meta.get("has_borders", True),
                two_column_layout=False,
            )
            out_list.append((r_title, md_txt, pdf_b))
          st.session_state["k2_roles_list"] = out_list

      if "k2_roles_list" in st.session_state:
        for idx, (r_title, md_txt, pdf_b) in enumerate(
            st.session_state["k2_roles_list"]
        ):
          with st.expander(f"📄 {r_title} (1-Page PDF)", expanded=(idx == 0)):
            st.markdown(md_txt)
            st.download_button(
                f"📥 Download {r_title} 1-Page Resume (.pdf)",
                data=pdf_b,
                file_name=f"Logaly_{r_title.replace(' ', '_')}_1Page.pdf",
                mime="application/pdf",
                key=f"dl_k2_{idx}",
            )

  with tab_k2_15:
    with st.container(border=True):
      st.markdown(
          "### 15 Distinct Resume Templates (Train Images & Generate Matched 1-Page PDF)"
      )
      st.caption(
          f"Folder: `{TEMPLATES_15_DIR}` — Supports both Two-Column Sidebar Photo layouts and Single-Column Executive/Editorial layouts."
      )

      uploaded_tpl_imgs = st.file_uploader(
          "Upload Template Images (PNG/JPG — up to 15)",
          type=["png", "jpg", "jpeg", "webp"],
          accept_multiple_files=True,
          key="upload_15_tpl_imgs",
      )
      if uploaded_tpl_imgs:
        os.makedirs(TEMPLATES_15_DIR, exist_ok=True)
        for i, u_img in enumerate(uploaded_tpl_imgs[:15], start=1):
          ext = os.path.splitext(u_img.name)[1] or ".png"
          save_p = os.path.join(TEMPLATES_15_DIR, f"template_{i:02d}{ext}")
          with open(save_p, "wb") as out_f:
            out_f.write(u_img.getbuffer())

      if st.button("📚 Train All 15 Templates", use_container_width=True):
        with st.spinner("Training all 15 template styles & image layouts..."):
          catalog = load_15_templates_from_folder_or_defaults()
          for item in catalog:
            item["trained_rules"] = (
                f"Follow {item['name']} strictly: layout='{item['layout']}', "
                f"two_column={item['two_column']}, texture='{item['texture']}', "
                f"accent='{item['accent']}', font='{item['font']}'. "
                f"Reference cues: {item.get('ocr_summary', '')[:250]}"
            )
          st.session_state["templates_15"] = catalog
          with open(TRAINED_15_JSON, "w", encoding="utf-8") as tf:
            json.dump({"templates": catalog}, tf, indent=2)
          st.success("All 15 templates trained and saved!")

      tpl_15 = st.session_state["templates_15"]
      cur_15 = min(max(st.session_state["tpl15_idx"], 0), len(tpl_15) - 1)

      c_prev, c_drop, c_next = st.columns([1, 3.2, 1])
      with c_prev:
        if st.button("⬅️ Previous", use_container_width=True, key="prev_15_btn"):
          st.session_state["tpl15_idx"] = (cur_15 - 1) % len(tpl_15)
          st.rerun()
      with c_drop:
        pick_name = st.selectbox(
            f"Choose Template ({cur_15 + 1} of {len(tpl_15)})",
            [t["name"] for t in tpl_15],
            index=cur_15,
            key="sel_15_tpl",
        )
        new_15 = [t["name"] for t in tpl_15].index(pick_name)
        if new_15 != cur_15:
          st.session_state["tpl15_idx"] = new_15
          st.rerun()
      with c_next:
        if st.button("Next ➡️", use_container_width=True, key="next_15_btn"):
          st.session_state["tpl15_idx"] = (cur_15 + 1) % len(tpl_15)
          st.rerun()

      active_tpl = tpl_15[st.session_state["tpl15_idx"]]
      st.markdown(
          f"**{active_tpl['name']}** — Layout: `{active_tpl['layout']}` | "
          f"Mode: `{'Two-Column Sidebar' if active_tpl.get('two_column') else 'Single-Column'}` | "
          f"Font: `{active_tpl['font']}`"
      )

      if active_tpl.get("image_path") and os.path.exists(
          active_tpl["image_path"]
      ):
        st.image(
            active_tpl["image_path"],
            caption=f"Trained Template Image: {active_tpl['name']}",
            use_container_width=True,
        )
      else:
        st.info(
            f"Place `template_{active_tpl['id']:02d}.png` in `templates_15/` to view its reference image here."
        )

      col_opt1, col_opt2 = st.columns(2)
      with col_opt1:
        use_two_col = st.checkbox(
            "Use Two-Column Sidebar Layout",
            value=bool(active_tpl.get("two_column")),
            key=f"twocol_chk_{active_tpl['id']}",
        )
      with col_opt2:
        include_photo = st.checkbox(
            "Include Optional Profile Photo",
            value=bool(active_tpl.get("photo")),
            key=f"photo_chk_{active_tpl['id']}",
        )

      photo_bytes = None
      if include_photo:
        u_photo = st.file_uploader(
            "Upload Profile Photo (Optional — PNG/JPG)",
            type=["png", "jpg", "jpeg"],
            key="tpl15_photo_uploader",
        )
        if u_photo is not None:
          photo_bytes = u_photo.read()

      if st.button(
          "🎨 Generate Single-Page Resume for Selected Template (.pdf)",
          use_container_width=True,
      ):
        with st.spinner(
            f"Generating matched single-page resume in {active_tpl['name']}..."
        ):
          gen_md = call_ai(
              f"""
Create a crisp, ATS-friendly single-page resume structured to match '{active_tpl['name']}'.
Layout Style: {active_tpl['layout']}
Texture/Tone: {active_tpl['texture']}
Apply all improvements from the combined analysis while preserving truthful resume skills, projects, education, LinkedIn, and GitHub details.
CRITICAL: Do NOT output '---' horizontal separator lines. Keep content well-proportioned so it fills ONE single page cleanly without spilling onto a second page.
Use '# Full Name' on line 1, contact details on line 2, and '## SECTION NAME' for section headings (include ## SKILLS, ## LANGUAGES, ## CERTIFICATIONS if using a sidebar template).
""",
              f"Template Training Rules: {active_tpl['trained_rules']}\n\nCombined Analysis:\n{combined_ctx}\n\nUser Resume:\n{st.session_state['pdf_text']}",
          )
          st.session_state["tpl15_md"] = gen_md
          st.session_state["tpl15_pdf"] = build_resume_pdf(
              gen_md,
              accent_hex=active_tpl["accent"],
              secondary_hex=active_tpl.get("secondary", active_tpl["accent"]),
              font_family=active_tpl["font"],
              use_border=active_tpl["border"],
              photo_bytes=photo_bytes,
              two_column_layout=use_two_col,
          )

      if "tpl15_md" in st.session_state:
        st.markdown("### 📄 Generated Single-Page Resume Preview")
        preview_png = render_pdf_page_png(
            st.session_state["tpl15_pdf"], 1, dpi=180
        )
        if preview_png:
          st.image(
              preview_png,
              caption=f"Generated 1-Page PDF Preview — {active_tpl['name']}",
              use_container_width=True,
          )
        else:
          st.markdown(st.session_state["tpl15_md"])

        st.download_button(
            f"📥 Download {active_tpl['name']} 1-Page Resume (.pdf)",
            data=st.session_state["tpl15_pdf"],
            file_name=f"Logaly_Template_{active_tpl['id']:02d}_1Page.pdf",
            mime="application/pdf",
        )

# ==============================================================================
# FEATURE 3: RESUME-TO-COMPANY MATCHER
# ==============================================================================
elif nav_choice == "3. Resume-to-Company Matcher":
  st.markdown("## 3️⃣ Resume-to-Company Matcher")

  if not st.session_state["pdf_text"]:
    st.warning("Upload your resume in **1. Resume & Role Input** first.")
    st.stop()

  combined_ctx = get_active_analysis_context()

  with st.container(border=True):
    c1, c2, c3 = st.columns(3)
    with c1:
      loc_mode = st.selectbox(
          "Location Option", ["Nearby", "By State", "Across India"]
      )
    with c2:
      if loc_mode == "Nearby":
        loc_val = st.text_input(
            "Current Location", value="Channapatna / Bengaluru, Karnataka"
        )
      elif loc_mode == "By State":
        loc_val = st.selectbox(
            "Select State",
            [
                "Karnataka",
                "Tamil Nadu",
                "Maharashtra",
                "Telangana",
                "Delhi NCR",
                "Gujarat",
                "Kerala",
            ],
        )
      else:
        loc_val = "Across India"
    with c3:
      exp_tier = st.selectbox(
          "Experience Filter",
          [
              "Fresher Jobs (0–1 yrs, Trainee, Graduate, Internship, Entry-Level)",
              "Experienced Jobs (1+, 2+, 3+, 5+ yrs & Specialist Roles)",
          ],
      )

    if st.button("🔎 Search Matching Companies", use_container_width=True):
      with st.spinner("Matching resume skills & combined analysis to companies..."):
        comp_sys = """
You are a Job Research Assistant. Analyze the user's resume and combined analysis to match real companies for the selected location and experience filter.
Never invent companies, openings, salaries, or status. Provide official company career links. If live hiring status is unverified, clearly state: "Status not verified".
Sort by Resume Match Percentage (highest first).
For every company provide:
1. Company Name | 2. Company Location | 3. Job Role / Position Available | 4. Hiring Category | 5. Experience Required | 6. Required Technical Skills | 7. Required Soft Skills | 8. Educational Qualification | 9. Salary Package (if publicly available) | 10. Job Description | 11. Official Application Link | 12. Hiring Status + Resume Match % & explanation.
"""
        st.session_state["company_matcher_out"] = call_ai(
            comp_sys,
            f"Location: {loc_mode} ({loc_val})\nFilter: {exp_tier}\n\nCombined Analysis:\n{combined_ctx}\n\nResume:\n{st.session_state['pdf_text']}",
        )

  if "company_matcher_out" in st.session_state:
    with st.container(border=True):
      st.markdown(st.session_state["company_matcher_out"])

# ==============================================================================
# FEATURE 4: CAREER ROADMAP
# ==============================================================================
elif nav_choice == "4. Career Roadmap":
  st.markdown("## 4️⃣ Career Roadmap")

  if not st.session_state["pdf_text"]:
    st.warning("Upload your resume in **1. Resume & Role Input** first.")
    st.stop()

  combined_ctx = get_active_analysis_context()

  with st.container(border=True):
    r1, r2 = st.columns(2)
    with r1:
      rm_goal = st.text_input(
          "Career Goal (Optional)", value=st.session_state["target_role"]
      )
    with r2:
      rm_hours = st.number_input(
          "Daily Study Hours (Default 2 hrs/day)",
          min_value=1,
          max_value=12,
          value=2,
      )

    if st.button("🧭 Generate Personalized Roadmap", use_container_width=True):
      with st.spinner("Building personalized roadmap from combined analysis..."):
        rm_sys = """
You are an AI Career Mentor, Technical Learning Architect, and Career Development Advisor.
Analyze the resume and combined analysis to produce sections A through K:
A. Resume Profile Summary | B. Current Skill Assessment (Beginner / Intermediate / Advanced / Not assessed) | C. Top 3 Recommended Career Paths | D. Personalized Roadmap Overview | E. Detailed Phase-by-Phase Roadmap (Phases 1–5) | F. Weekly Learning Plan | G. Recommended Projects (Beginner, Intermediate, Industry-level) | H. Recommended Learning Resources | I. Job Readiness Checklist | J. Career Milestones | K. Estimated Time to Become Job Ready.
Never guarantee job placement.
"""
        st.session_state["roadmap_out"] = call_ai(
            rm_sys,
            f"Goal: {rm_goal}\nStudy Time: {rm_hours} hrs/day\n\nCombined Analysis:\n{combined_ctx}\n\nResume:\n{st.session_state['pdf_text']}",
        )

  if "roadmap_out" in st.session_state:
    with st.container(border=True):
      st.markdown(st.session_state["roadmap_out"])

# ==============================================================================
# FEATURE 5: SKILL GAP ANALYZER
# ==============================================================================
elif nav_choice == "5. Skill Gap Analyzer":
  st.markdown("## 5️⃣ Skill Gap Analyzer")

  if not st.session_state["pdf_text"]:
    st.warning("Upload your resume in **1. Resume & Role Input** first.")
    st.stop()

  combined_ctx = get_active_analysis_context()

  with st.container(border=True):
    s1, s2, s3 = st.columns(3)
    with s1:
      sg_title = st.text_input(
          "Target Job Title", value=st.session_state["target_role"]
      )
    with s2:
      sg_comp = st.text_input("Target Company (Optional)")
    with s3:
      sg_dur = st.text_input("Learning Duration (Optional)")
    sg_jd = st.text_area(
        "Target Job Description (Optional)",
        value=st.session_state["job_description"],
        height=120,
    )

    if st.button("🔍 Run Skill Gap Analysis", use_container_width=True):
      with st.spinner("Calculating weighted match & skill gaps..."):
        sg_sys = """
You are an expert Technical Recruiter, Job Requirement Analyst, ATS Specialist, and Career Skill Evaluator.
Weighting: Mandatory technical skills 50%, Preferred technical skills 20%, Relevant projects/experience 15%, Education 10%, Soft skills 5%.
Readiness levels: 0–39% Foundation Required, 40–59% Developing Candidate, 60–74% Near Job Ready, 75–89% Competitive Candidate, 90–100% Strong Skill Alignment.
Output sections A through L:
A. Target Job Overview | B. Resume Skills Extracted | C. Job Requirements | D. Skill Comparison Table (Strong Match / Partial Match / Missing Skill / Needs Validation) | E. Overall Match Percentage | F. Strong Skills | G. Missing Skills | H. Skills Requiring Improvement | I. Prioritized Skill Gap List (Critical / High / Medium / Low) | J. Personalized Learning Plan | K. Recommended Projects | L. Job Readiness Assessment.
"""
        st.session_state["skill_gap_out"] = call_ai(
            sg_sys,
            f"Role: {sg_title}\nCompany: {sg_comp}\nDuration: {sg_dur}\nJD:\n{sg_jd}\n\nCombined Analysis:\n{combined_ctx}\n\nResume:\n{st.session_state['pdf_text']}",
        )

  if "skill_gap_out" in st.session_state:
    with st.container(border=True):
      st.markdown(st.session_state["skill_gap_out"])

# ==============================================================================
# FEATURE 6: INTERVIEW PREPARATION
# ==============================================================================
elif nav_choice == "6. Interview Preparation":
  st.markdown("## 6️⃣ Interview Preparation")

  if not st.session_state["pdf_text"]:
    st.warning("Upload your resume in **1. Resume & Role Input** first.")
    st.stop()

  combined_ctx = get_active_analysis_context()
  i_tab1, i_tab2 = st.tabs(
      ["🎙️ Interactive Mock Interview", "📚 Question Bank & Study Plan"]
  )

  with i_tab1:
    with st.container(border=True):
      ic1, ic2, ic3 = st.columns(3)
      with ic1:
        iv_role = st.text_input(
            "Target Role",
            value=st.session_state["target_role"] or "Software Developer",
        )
      with ic2:
        iv_diff = st.selectbox(
            "Interview Difficulty", ["Beginner", "Intermediate", "Advanced"]
        )
      with ic3:
        iv_type = st.selectbox(
            "Interview Type",
            [
                "Full Mock Interview",
                "Technical",
                "HR",
                "Coding",
                "Project-Based",
            ],
        )

      b1, b2 = st.columns(2)
      with b1:
        if st.button("▶️ Start Mock Interview", use_container_width=True):
          st.session_state["interview_active"] = True
          st.session_state["interview_history"] = []
          with st.spinner("Generating Question 1..."):
            q1 = call_ai(
                f"You are a Technical Interviewer & HR Coach conducting a {iv_diff} {iv_type} interview for {iv_role}. Ask ONLY Question 1 based on the resume and combined analysis. Do not reveal the answer yet.",
                f"Combined Analysis:\n{combined_ctx}\n\nResume:\n{st.session_state['pdf_text']}\nJD:\n{st.session_state['job_description']}",
            )
            st.session_state["interview_history"].append(
                {"role": "interviewer", "content": q1}
            )
      with b2:
        if st.button("🏁 End & Generate Final Report", use_container_width=True):
          if st.session_state["interview_history"]:
            with st.spinner("Generating Final Performance Report..."):
              hist_txt = "\n\n".join(
                  f"{m['role'].upper()}: {m['content']}"
                  for m in st.session_state["interview_history"]
              )
              st.session_state["final_iv_report"] = call_ai(
                  "Provide Final Mock Interview Report with Overall Score out of 100, Technical/Project/Coding/Communication/Problem-Solving scores, Strengths, Weaknesses, Weak Topic Study Plan, and Readiness Level.",
                  f"Combined Analysis:\n{combined_ctx}\n\nResume:\n{st.session_state['pdf_text']}\n\nInterview:\n{hist_txt}",
              )

    if st.session_state["interview_active"]:
      for m in st.session_state["interview_history"]:
        with st.container(border=True):
          st.markdown(
              f"**{'🧑‍💼 Interviewer' if m['role'] == 'interviewer' else '🙋 You'}:**\n\n{m['content']}"
          )

      ans_in = st.text_area("Your Answer:", height=110, key="iv_ans_input")
      if st.button("Submit Answer & Get Next Question"):
        if ans_in.strip():
          st.session_state["interview_history"].append(
              {"role": "candidate", "content": ans_in}
          )
          hist_txt = "\n\n".join(
              f"{m['role'].upper()}: {m['content']}"
              for m in st.session_state["interview_history"]
          )
          with st.spinner("Evaluating answer & asking next question..."):
            nxt = call_ai(
                f"Evaluate the candidate's latest answer (Score out of 10, what was correct, what was missing/improved, sample answer, tip) for a {iv_diff} {iv_type} interview ({iv_role}), then ask ONLY the next question.",
                f"Combined Analysis:\n{combined_ctx}\n\nResume:\n{st.session_state['pdf_text']}\n\nInterview:\n{hist_txt}",
            )
            st.session_state["interview_history"].append(
                {"role": "interviewer", "content": nxt}
            )
            st.rerun()

    if "final_iv_report" in st.session_state:
      with st.container(border=True):
        st.markdown("### 📋 Final Mock Interview Performance Report")
        st.markdown(st.session_state["final_iv_report"])

  with i_tab2:
    with st.container(border=True):
      if st.button("📖 Generate Question Bank & Study Plan"):
        with st.spinner("Generating interview questions..."):
          st.session_state["qbank_out"] = call_ai(
              "Generate Technical, Resume/Project-Based, Coding/SQL (with constraints & hints, without revealing full solutions immediately), HR/Behavioral, and Job-Specific interview questions plus a study plan based on the resume and combined analysis.",
              f"Role: {st.session_state['target_role']}\nJD: {st.session_state['job_description']}\nCombined Analysis:\n{combined_ctx}\n\nResume:\n{st.session_state['pdf_text']}",
          )
      if "qbank_out" in st.session_state:
        st.markdown(st.session_state["qbank_out"])

# ==============================================================================
# FEATURE 7: FEEDBACK & USER RATING SYSTEM + SHARE FEEDBACK PROMPT
# ==============================================================================
elif nav_choice == "7. Feedback":
  st.markdown("## 7️⃣ Feedback & User Rating System")

  reviews = load_feedback()
  total_rev = len(reviews)
  avg_star = (
      round(sum(r["rating"] for r in reviews) / total_rev, 2)
      if total_rev > 0
      else 0.0
  )
  pos_rate = (
      round(sum(1 for r in reviews if r["rating"] >= 4) / total_rev * 100, 1)
      if total_rev > 0
      else 0.0
  )

  m1, m2, m3 = st.columns(3)
  m1.metric("Average Rating", f"{avg_star} / 5.0 ⭐")
  m2.metric("Total Reviews", total_rev)
  m3.metric("Positive Reviews (4–5★)", f"{pos_rate}%")

  if total_rev > 0:
    with st.container(border=True):
      st.markdown("**Star Rating Distribution**")
      for s in [5, 4, 3, 2, 1]:
        cnt = sum(1 for r in reviews if r["rating"] == s)
        st.progress(cnt / total_rev, text=f"{s} ★ ({cnt})")

  with st.container(border=True):
    st.markdown("### ✍️ Submit Feedback")
    f1, f2 = st.columns(2)
    with f1:
      rating_val = st.radio(
          "Star Rating *",
          [5, 4, 3, 2, 1],
          format_func=lambda s: f"{'★' * s}{'☆' * (5 - s)} ({s} - {['Poor', 'Needs Improvement', 'Average', 'Good', 'Excellent'][s-1]})",
          horizontal=True,
      )
      cat_val = st.selectbox(
          "Category",
          [
              "Overall Experience",
              "Resume Analysis",
              "Resume Implementation",
              "Company Finder",
              "Career Roadmap",
              "Skill Gap Analyzer",
              "Interview Preparation",
              "UI/UX Design",
              "Performance",
              "Other",
          ],
      )
    with f2:
      user_disp = st.text_input("Display Name", value="Sha Niyamath")
      is_anon = st.checkbox("Submit Anonymously")
      rev_title = st.text_input("Feedback Title (Optional)", max_chars=80)

    rev_body = st.text_area(
        "Written Feedback *",
        placeholder="Write your feedback about Logaly...",
        max_chars=1000,
    )
    rev_sug = st.text_input("Improvement Suggestion (Optional)", max_chars=300)

    if st.button("Submit Feedback", use_container_width=True):
      if not rev_body.strip():
        st.error("Please write your feedback before submitting.")
      else:
        entry = {
            "id": f"fb_{int(datetime.now().timestamp() * 1000)}",
            "user": (
                "Anonymous User"
                if is_anon or not user_disp.strip()
                else user_disp.strip()
            ),
            "rating": rating_val,
            "category": cat_val,
            "title": rev_title.strip() or f"{rating_val}-Star Review",
            "review": rev_body.strip(),
            "suggestion": rev_sug.strip(),
            "date": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "helpful": 0,
        }
        reviews.insert(0, entry)
        save_feedback(reviews)
        st.success("Feedback submitted and saved!")
        st.rerun()

  with st.container(border=True):
    st.markdown("### 📤 Share Feedback Prompt")
    if st.button("Generate Shareable Feedback Prompt"):
      prompt_share = f"""Update Logaly (AI Resume & Career Suite) based on this user feedback:
- Rating: {rating_val}/5 stars
- Category: {cat_val}
- Feedback: {rev_body.strip() or 'No review text entered yet.'}
- Suggestion: {rev_sug.strip() or 'None'}
Please review and apply these improvements cleanly to the project."""
      st.session_state["shared_fb_prompt"] = prompt_share

    if "shared_fb_prompt" in st.session_state:
      st.code(st.session_state["shared_fb_prompt"], language="text")
      st.download_button(
          "📥 Download Feedback Prompt (.txt)",
          data=st.session_state["shared_fb_prompt"],
          file_name="Logaly_Feedback_Prompt.txt",
          mime="text/plain",
      )

  st.markdown("### 📋 Submitted Reviews")
  if not reviews:
    with st.container(border=True):
      st.info("No reviews submitted yet.")
  else:
    fl1, fl2, fl3 = st.columns(3)
    with fl1:
      f_star = st.selectbox(
          "Filter Rating",
          [
              "All",
              "Positive (4–5★)",
              "Critical (1–3★)",
              "5★",
              "4★",
              "3★",
              "2★",
              "1★",
          ],
      )
    with fl2:
      f_cat = st.selectbox(
          "Filter Category",
          ["All Categories"] + sorted(list({r["category"] for r in reviews})),
      )
    with fl3:
      f_sort = st.selectbox(
          "Sort By",
          ["Newest", "Highest Rating", "Lowest Rating", "Most Helpful"],
      )

    view_list = list(reviews)
    if f_star == "Positive (4–5★)":
      view_list = [r for r in view_list if r["rating"] >= 4]
    elif f_star == "Critical (1–3★)":
      view_list = [r for r in view_list if r["rating"] <= 3]
    elif f_star.endswith("★"):
      view_list = [r for r in view_list if r["rating"] == int(f_star[0])]

    if f_cat != "All Categories":
      view_list = [r for r in view_list if r["category"] == f_cat]

    if f_sort == "Highest Rating":
      view_list.sort(key=lambda x: x["rating"], reverse=True)
    elif f_sort == "Lowest Rating":
      view_list.sort(key=lambda x: x["rating"])
    elif f_sort == "Most Helpful":
      view_list.sort(key=lambda x: x["helpful"], reverse=True)

    for r in view_list:
      with st.container(border=True):
        c_left, c_right = st.columns([4, 1])
        with c_left:
          st.markdown(
              f"**{r['title']}** &nbsp; {'⭐' * r['rating']} &nbsp; `[{r['category']}]`"
          )
          st.caption(f"By **{r['user']}** • {r['date']}")
          st.write(r["review"])
          if r.get("suggestion"):
            st.caption(f"💡 Suggestion: {r['suggestion']}")
        with c_right:
          voted = r["id"] in st.session_state["voted_reviews"]
          if st.button(
              f"👍 Helpful ({r['helpful']})",
              key=f"helpful_{r['id']}",
              disabled=voted,
          ):
            for item in reviews:
              if item["id"] == r["id"]:
                item["helpful"] += 1
            st.session_state["voted_reviews"].append(r["id"])
            save_feedback(reviews)
            st.rerun()