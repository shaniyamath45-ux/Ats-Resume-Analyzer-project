# Advanced-ATS-Resume-Checker


### What's This All About?

75% of resumes never reach human eyes. They're killed by ATS (Applicant Tracking Systems).

ResumeATS Pro is here to change that game.

### What Does It Do?

1. Analyzes resumes like an ATS would
2. Gives actionable feedback
3. Helps optimize resumes for ATS approval
4. Provides a chat feature for personalized advice

### Why Should You Care?

- If you're a job seeker: This tool could be your ticket to more interviews
- If you're a developer: You can help change lives (and maybe land a cool job yourself)

### Tech Stack

- Frontend: Streamlit
- AI Brain: Google's Geneai
- PDF Handling: PyPDF2

### How to Use

1. Create a virtual environment and start the virtual environment in your VSCode

2. create the environment (Windows)
Method 1: Using VS Code (Recommended)
Step 1: Open your project
Open VS Code.
Click File → Open Folder.
Select your ResumeATS Pro project folder.
Step 2: Open the Command Palette
Press:
Ctrl + Shift + P
Step 3: Create the environment
Search for Python: Create Environment.
Select Venv.
Select Python 3.10.
Wait for VS Code to create the environment.
Step 4: Select the interpreter
If VS Code asks you to select an interpreter, choose the one inside:
ResumeATS Pro\.venv\Scripts\python.exe
Method 2: Using the Terminal
Open VS Code Terminal (Ctrl + ~).
Run these commands one by one:
1. Create virtual environment
py -3.10 -m venv .venv
2. Activate virtual environment
.venv\Scripts\activate
3. Upgrade pip
python -m pip install --upgrade pip
4. Install project requirements
python -m pip install -r requirements.txt
How to check whether it worked
Your VS Code terminal should display:
(.venv) C:\YourProject>
You can also check the Python version:
python --version
Expected output:
Python 3.10.x
5. upgrade the pip
python -m pip install --upgrade pip

3. Install dependencies: `python -m pip install -r requirements.txt`

4. Set up your Google API key in a `.env` file

6. install all library 
   python -m pip install streamlit openai python-dotenv PyPDF2 pdfplumber pytesseract pdf2image reportlab

6. # Poppler Setup for 61 Resume Templates (Windows)

## Overview

The **Advanced ATS Resume Checker** uses a 61-page resume template PDF to display professional resume templates in the Streamlit application.

To display individual PDF pages as high-quality images, the application uses the `pdf2image` Python library. However, `pdf2image` requires an external utility called **Poppler** to convert PDF pages into images.

On Windows, Poppler provides the executable `pdftoppm.exe`, which is used to render PDF pages.

Without Poppler correctly installed and configured, the application may encounter errors such as:

- PDF pages not rendering.
- Blank template previews.
- `PDFInfoNotInstalledError`.
- `Unable to get page count`.
- `pdftoppm is not recognized`.
- Failure to display full-screen resume templates.

---

## 1. Requirements

Before installing Poppler, ensure the following are available:

- Windows 10 or Windows 11.
- Python installed.
- Project virtual environment (`.venv`) configured.
- Streamlit installed.
- `pdf2image` installed.
- The 61-page resume template PDF available in the project.

Install the Python dependency if it is not already installed:

```bash
pip install pdf2image
```

---

## 2. Download Poppler for Windows

Download the Windows release of Poppler from:

https://github.com/oschwartz10612/poppler-windows/releases

Download the release ZIP file, not the source code.

Example release:

**Release-26.09.0-0.zip**

Download:

https://github.com/oschwartz10612/poppler-windows/releases/download/v26.09.0-0/Release-26.09.0-0.zip

---

## 3. Extract Poppler

After downloading:

1. Open the Downloads folder.
2. Right-click the Poppler ZIP file.
3. Select **Extract All**.
4. Extract the files to a convenient location.

Example extracted location:

```text
C:\Users\YourUsername\Documents\poppler-26.09.0
```

Avoid deleting the extracted files after configuring Poppler because Windows PATH must point to the actual Poppler binary directory.

---

## 4. Locate `pdftoppm.exe`

Inside the extracted Poppler directory, locate the `bin` folder.

Typical folder structure:

```text
poppler-26.09.0
└── Library
    └── bin
        ├── pdftoppm.exe
        ├── pdfinfo.exe
        └── other Poppler executables
```

The important executable is:

```text
pdftoppm.exe
```

The directory containing this executable must be added to Windows PATH.

---

## 5. Configure Windows PATH

Adding Poppler to PATH allows Python and Streamlit to locate the PDF rendering utilities without specifying the executable location every time.

### Steps

1. Press the Windows key.
2. Search for **Environment Variables**.
3. Select **Edit the system environment variables**.
4. In the System Properties window, click **Environment Variables**.
5. Under **User variables**, select `Path`.
6. Click **Edit**.
7. Click **New**.
8. Add the path to Poppler's `bin` directory.

Example:

```text
C:\Users\YourUsername\Documents\poppler-26.09.0\Library\bin
```

9. Click **OK** to save.
10. Click **OK** on all remaining windows.

> Add the directory containing `pdftoppm.exe` to PATH, not the Poppler root folder.

---

## 6. Verify Poppler Installation

Close any open terminals and open a new PowerShell terminal.

Run:

```powershell
pdftoppm -v
```

If Poppler is installed correctly, the terminal should display version information.

### Expected result

```text
pdftoppm version 26.09.0
```

The exact version output may vary depending on the installed release.

If Windows displays:

```text
pdftoppm : The term 'pdftoppm' is not recognized
```

Check:

- Whether Poppler was extracted successfully.
- Whether the PATH points to the correct `bin` folder.
- Whether `pdftoppm.exe` exists in that folder.
- Whether a new terminal was opened after changing PATH.

---

## 7. Restart the Streamlit Application

After Poppler has been configured:

1. Open the project in Visual Studio Code.
2. Open a new terminal.
3. Activate the virtual environment if it is not already active.

```powershell
.\.venv\Scripts\Activate.ps1
```

4. Start the application:

```bash
streamlit run app.py
```

5. Open the application in your browser.
6. Navigate to:

**Resume Implementation → Kind 2B: 61 Trained Templates**

7. Select a template.
8. Verify that the template preview displays correctly.

That's okay — don't worry. This error means **Windows cannot find Poppler**, even though you downloaded and extracted it. Most likely, the PATH setting hasn't been added correctly, or your terminal hasn't refreshed it yet.

Your Poppler folder is already known:

```
C:\Users\shaniyamath\OneDrive\Documents\poppler-26.09.0\Library\bin
```

Let's fix this without reinstalling anything.

## **Step 1 — Check that Poppler actually exists**

In your VS Code PowerShell terminal, copy and paste this command:

```
Test-Path "C:\Users\shaniyamath\OneDrive\Documents\poppler-26.09.0\Library\bin\pdftoppm.exe"
```

Press **Enter**.

### **What should it show?**

True

- **True** → Poppler is installed correctly. We just need to fix the PATH.
- **False** → The folder location is incorrect, and we'll find the correct location.

Run this command and **send me exactly what appears:&#x20;**`True`**&#x20;or&#x20;**`False`. Then I'll give you the next step based on your result.

Perfect! ✅ This confirms **Poppler is installed correctly**, and `pdftoppm.exe` exists on your computer.

The only problem is that Windows hasn't added Poppler to the PATH correctly. We can fix this without downloading anything again.

## **Step 2 — Temporarily fix PATH in your VS Code terminal**

Since the file already exists, let's test Poppler directly in your current terminal.

Copy and paste this command into PowerShell:

```
$env:Path += ";C:\Users\shaniyamath\OneDrive\Documents\poppler-26.09.0\Library\bin"
```

Press **Enter**.

This adds Poppler to the PATH for your current terminal session only. It doesn't permanently change Windows settings.

### **Step 3 — Test Poppler again**

Now copy and run:

```
pdftoppm -v
```

### **Expected result**

You should see something similar to:

```
pdftoppm version 26.09.0
```

If you see the version information, Poppler is working! 🎉

This temporary fix is enough to test your resume template previews. Later, we can make it permanent so you don't need to repeat the PATH command every time.

**Run&#x20;**`pdftoppm -v`**&#x20;now and send me the output.**


7. Run with: `streamlit run app.py`


### License

MIT License. See `LICENSE` for more information.